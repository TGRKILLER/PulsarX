@echo off
setlocal enabledelayedexpansion
mode con: cols=80 lines=30
color 0B
cls

REM ============================================================================
REM                          PULSAR TOOL LAUNCHER
REM ============================================================================

REM Display banner
cls
echo.
echo.
echo                          *                    *
echo                         * *                  * *
echo                        * * *    PULSAR     * * *
echo                         * *      TOOL       * *
echo                          *                    *
echo.
echo                    ========== v1.0 =========
echo                          By: Killer.lmao
echo.
echo                   Loading... Please Wait
echo.

REM Create a more sophisticated loading animation
set "frame[0]=   |   "
set "frame[1]=   /   "
set "frame[2]=   -   "
set "frame[3]=   \   "

set "bar[0]=[          ]"
set "bar[1]=[#         ]"
set "bar[2]=[##        ]"
set "bar[3]=[###       ]"
set "bar[4]=[####      ]"
set "bar[5]=[#####     ]"
set "bar[6]=[######    ]"
set "bar[7]=[#######   ]"
set "bar[8]=[########  ]"
set "bar[9]=[########## ]"
set "bar[10]=[###########]"

echo.
echo                        Initializing Modules:
echo.

REM Simulate module loading
call :load_module "IP Tools"
call :load_module "Geolocation Engine"
call :load_module "C# Processors"
call :load_module "Database Cache"

cls
echo.
echo.
echo                          *                    *
echo                         * *                  * *
echo                        * * *    PULSAR     * * *
echo                         * *      TOOL       * *
echo                          *                    *
echo.
echo                    ========== v1.0 =========
echo                          By: Killer.lmao
echo.
echo.
echo                    Final Initialization: !bar[10]!
echo.
echo                         100%% COMPLETE
echo.
echo.

timeout /t 1 /nobreak >nul

cls
echo.
echo.
echo                          *                    *
echo                         * *                  * *
echo                        * * *    PULSAR     * * *
echo                         * *      TOOL       * *
echo                          *                    *
echo.
echo                    ========== v1.0 =========
echo                        By: Killer.lmao
echo.
echo.
echo                      LAUNCHING APPLICATION
echo.

REM Spinning animation during final launch
for /l %%A in (1,1,4) do (
    cls
    echo.
    echo.
    echo                          *                    *
    echo                         * *                  * *
    echo                        * * *    PULSAR     * * *
    echo                         * *      TOOL       * *
    echo                          *                    *
    echo.
    echo                    ========== v1.0 =========
    echo                          By: Killer.lmao
    echo.
    echo.
    if %%A equ 1 (
        echo                        LAUNCHING  ^|
    ) else if %%A equ 2 (
        echo                        LAUNCHING  /
    ) else if %%A equ 3 (
        echo                        LAUNCHING  -
    ) else (
        echo                        LAUNCHING  \
    )
    echo.
    timeout /t 0 /nobreak >nul
)

REM Find and execute the compiled .exe
cd /d "%~dp0"

REM Try Release build first
if exist "bin\Release\Pulsar_tool.exe" (
    start "" "bin\Release\Pulsar tool.exe"
    goto :exit
)

REM Fall back to Debug build
if exist "bin\Debug\Pulsar_tool.exe" (
    start "" "bin\Debug\Pulsar tool.exe"
    goto :exit
)

REM Search in project directory
if exist "Pulsar tool.exe" (
    start "" "Pulsar tool.exe"
    goto :exit
)

REM If not found in expected locations, search the directory
for /r "." %%F in (Pulsar tool.exe) do (
    start "" "%%F"
    goto :exit
)

REM Error if not found
color 04
cls
echo.
echo.
echo                     ERROR - Executable Not Found!
echo.
echo   Please ensure the application has been built.
echo   Expected location: bin\Release\Pulsar_tool.exe
echo                   or bin\Debug\Pulsar tool.exe
echo.
echo   Searched locations:
echo   - bin\Release\
echo   - bin\Debug\
echo   - Current directory
echo.
timeout /t 5 /nobreak >nul

:exit
exit /b

REM ============================================================================
REM SUBROUTINE: Load Module with animation
REM ============================================================================
:load_module
setlocal enabledelayedexpansion
set "module=%~1"

for /l %%B in (0,1,10) do (
    cls
    echo.
    echo.
    echo                          *                    *
    echo                         * *                  * *
    echo                        * * *    PULSAR     * * *
    echo                         * *      TOOL       * *
    echo                          *                    *
    echo.
    echo                    ========== v1.0 =========
    echo                          By: Killer.lmao
    echo.
    echo.
    echo                        Initializing Modules:
    echo.
    echo                    !bar[%%B]!  !module!
    echo.
    timeout /t 0 /nobreak >nul
)

endlocal
exit /b